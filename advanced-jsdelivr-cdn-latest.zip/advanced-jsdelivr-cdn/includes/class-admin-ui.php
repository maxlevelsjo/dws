<?php
class Advanced_JSDelivr_Admin_UI {
    private $settings;
    private $github_sync;
    private $mappings;
    
    public function __construct($settings, $github_sync, $mappings) {
        $this->settings = $settings;
        $this->github_sync = $github_sync;
        $this->mappings = $mappings;
        
        $this->init_hooks();
    }
    
    private function init_hooks() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'admin_scripts'));
        
        // AJAX handlers
        add_action('wp_ajax_test_github_connection', array($this, 'ajax_test_github_connection'));
        add_action('wp_ajax_sync_selected_files', array($this, 'ajax_sync_selected_files'));
        add_action('wp_ajax_sync_full_wpcontent', array($this, 'ajax_sync_full_wpcontent'));
    }
    
    public function add_admin_menu() {
        $menu_icon = 'dashicons-performance';
        
        add_menu_page(
            __('jsDelivr CDN', 'advanced-jsdelivr-cdn'),
            __('jsDelivr CDN', 'advanced-jsdelivr-cdn'),
            'manage_options',
            'advanced-jsdelivr-cdn',
            array($this, 'render_settings_page'),
            $menu_icon
        );
        
        add_submenu_page(
            'advanced-jsdelivr-cdn',
            __('CDN Settings', 'advanced-jsdelivr-cdn'),
            __('Settings', 'advanced-jsdelivr-cdn'),
            'manage_options',
            'advanced-jsdelivr-cdn',
            array($this, 'render_settings_page')
        );
        
        add_submenu_page(
            'advanced-jsdelivr-cdn',
            __('CDN Mappings', 'advanced-jsdelivr-cdn'),
            __('Mappings', 'advanced-jsdelivr-cdn'),
            'manage_options',
            'advanced-jsdelivr-mappings',
            array($this, 'render_mappings_page')
        );
        
        add_submenu_page(
            'advanced-jsdelivr-cdn',
            __('GitHub Sync', 'advanced-jsdelivr-cdn'),
            __('GitHub Sync', 'advanced-jsdelivr-cdn'),
            'manage_options',
            'advanced-jsdelivr-sync',
            array($this, 'render_sync_page')
        );
    }
    
    public function register_settings() {
        $this->settings->register_settings();
    }
    
    public function admin_scripts($hook) {
        if (strpos($hook, 'advanced-jsdelivr') === false) {
            return;
        }
        
        wp_enqueue_style(
            'advanced-jsdelivr-admin',
            ADVANCED_JSDELIVR_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            ADVANCED_JSDELIVR_VERSION
        );
        
        wp_enqueue_script(
            'advanced-jsdelivr-admin', 
            ADVANCED_JSDELIVR_PLUGIN_URL . 'assets/js/admin.js', 
            array('jquery'), 
            ADVANCED_JSDELIVR_VERSION, 
            true
        );
        
        wp_localize_script('advanced-jsdelivr-admin', 'advanced_jsdelivr', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('advanced_jsdelivr_nonce'),
            'testing_connection' => __('Testing connection...', 'advanced-jsdelivr-cdn'),
            'syncing_files' => __('Syncing files...', 'advanced-jsdelivr-cdn'),
            'confirm_full_sync' => __('Are you sure you want to sync your entire wp-content directory? This may take a while.', 'advanced-jsdelivr-cdn')
        ));
    }
    
    public function render_settings_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'advanced-jsdelivr-cdn'));
    }

    // Pass the required data to the template
    $data = [
        'settings' => $this->settings,
        'github_auto_upload' => $this->settings->get_option('github_auto_upload', 'no')
    ];
    
    extract($data);
    include ADVANCED_JSDELIVR_PLUGIN_DIR . 'templates/settings-page.php';
}
    
    public function render_mappings_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'advanced-jsdelivr-cdn'));
        }
        
        include ADVANCED_JSDELIVR_PLUGIN_DIR . 'templates/mappings-page.php';
    }
    
public function render_sync_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'advanced-jsdelivr-cdn'));
    }

    // Pass the settings to the template
    $data = [
        'settings' => $this->settings->get_all_options(),
        'sync_file_types' => $this->settings->get_option('sync_file_types', [])
    ];
    
    extract($data);
    include ADVANCED_JSDELIVR_PLUGIN_DIR . 'templates/sync-page.php';
}
    
    public function ajax_test_github_connection() {
    // Verify nonce and permissions
    if (!check_ajax_referer('advanced_jsdelivr_test_connection', '_ajax_nonce', false)) {
        wp_send_json_error(
            __('Security verification failed.', 'advanced-jsdelivr-cdn'),
            403
        );
        wp_die();
    }

    if (!current_user_can('manage_options')) {
        wp_send_json_error(
            __('Permission denied.', 'advanced-jsdelivr-cdn'),
            403
        );
        wp_die();
    }
    
    try {
        $result = $this->github_sync->test_github_connection();
        
        if ($result['success']) {
            wp_send_json_success($result['message']);
        } else {
            wp_send_json_error($result['message']);
        }
    } catch (Exception $e) {
        wp_send_json_error(
            sprintf(
                __('Connection test failed: %s', 'advanced-jsdelivr-cdn'),
                $e->getMessage()
            ),
            500
        );
    }
}
    
    public function ajax_sync_selected_files() {
        check_ajax_referer('advanced_jsdelivr_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have sufficient permissions.', 'advanced-jsdelivr-cdn'));
        }
        
        $file_types = isset($_POST['file_types']) ? (array)$_POST['file_types'] : array();
        
        if (empty($file_types)) {
            wp_send_json_error(__('No file types selected for sync.', 'advanced-jsdelivr-cdn'));
        }
        
        try {
            $results = $this->github_sync->sync_selected_files($file_types);
            
            $success_count = count(array_filter($results, function($item) {
                return $item['success'];
            }));
            
            $message = sprintf(
                _n('Successfully synced %d file.', 'Successfully synced %d files.', $success_count, 'advanced-jsdelivr-cdn'),
                $success_count
            );
            
            wp_send_json_success(array(
                'message' => $message,
                'results' => $results
            ));
        } catch (Exception $e) {
            wp_send_json_error(sprintf(
                __('Sync failed: %s', 'advanced-jsdelivr-cdn'),
                $e->getMessage()
            ));
        }
    }
    
    public function ajax_sync_full_wpcontent() {
        check_ajax_referer('advanced_jsdelivr_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('You do not have sufficient permissions.', 'advanced-jsdelivr-cdn'));
        }
        
        try {
            $results = $this->github_sync->sync_full_wpcontent();
            
            $success_count = count(array_filter($results, function($item) {
                return $item['success'];
            }));
            
            $message = sprintf(
                _n('Successfully synced %d file from wp-content.', 'Successfully synced %d files from wp-content.', $success_count, 'advanced-jsdelivr-cdn'),
                $success_count
            );
            
            wp_send_json_success(array(
                'message' => $message,
                'results' => $results
            ));
        } catch (Exception $e) {
            wp_send_json_error(sprintf(
                __('Full sync failed: %s', 'advanced-jsdelivr-cdn'),
                $e->getMessage()
            ));
        }
    }
}