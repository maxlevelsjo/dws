<?php
class Advanced_JSDelivr_Github_Sync {
    private $settings;
    
    public function __construct($settings) {
        $this->settings = $settings;
    }
    
    public function handle_attachment_upload($attachment_id) {
        if ($this->settings->get_option('github_auto_upload') !== 'yes') return;
        
        $file_path = get_attached_file($attachment_id);
        $github_path = str_replace(ABSPATH, '', $file_path);
        
        $this->upload_to_github($file_path, $github_path);
    }
    
    public function handle_theme_plugin_update($upgrader, $options) {
        if ($this->settings->get_option('github_auto_upload') !== 'yes') return;
        
        if ($options['action'] == 'update' && $options['type'] == 'theme') {
            $theme = wp_get_theme();
            $theme_dir = get_template_directory();
            $this->sync_directory_to_github($theme_dir, 'wp-content/themes/' . $theme->get_stylesheet());
        }
    }
    
    public function test_github_connection() {
    // First verify we have required credentials
    if (empty($this->settings->get_option('github_username'))) {
        return [
            'success' => false,
            'message' => __('GitHub username is missing', 'advanced-jsdelivr-cdn')
        ];
    }

    $api_url = 'https://api.github.com/repos/' . 
              $this->settings->get_option('github_username') . '/' . 
              $this->settings->get_option('github_repo');

    $args = [
        'headers' => [
            'Authorization' => 'token ' . $this->settings->get_option('github_token'),
            'Accept' => 'application/vnd.github.v3+json',
            'User-Agent' => 'WordPress/jsDelivr-CDN-Manager'
        ],
        'timeout' => 20, // Increased timeout to 20 seconds
        'sslverify' => false // Only if you're having SSL issues
    ];

    // Add debug logging
    error_log('Attempting to connect to GitHub: ' . $api_url);

    $response = wp_remote_get($api_url, $args);

    if (is_wp_error($response)) {
        error_log('GitHub connection error: ' . $response->get_error_message());
        return [
            'success' => false,
            'message' => __('Could not connect to GitHub API', 'advanced-jsdelivr-cdn')
        ];
    }

    $response_code = wp_remote_retrieve_response_code($response);
    $response_body = wp_remote_retrieve_body($response);
    
    if ($response_code === 200) {
        return array(
            'success' => true,
            'message' => __('Connection to GitHub successful!', 'advanced-jsdelivr-cdn')
        );
    } elseif ($response_code === 404) {
        return array(
            'success' => false,
            'message' => __('Repository not found. Please check your username and repository name.', 'advanced-jsdelivr-cdn')
        );
    } elseif ($response_code === 401) {
        return array(
            'success' => false,
            'message' => __('Authentication failed. Please check your GitHub token.', 'advanced-jsdelivr-cdn')
        );
    } else {
        return array(
            'success' => false,
            'message' => sprintf(
                __('Unexpected error. GitHub API returned code %d', 'advanced-jsdelivr-cdn'),
                $response_code
            )
        );
    }
}
    
    public function sync_selected_files($file_types = array()) {
        $upload_dir = wp_upload_dir();
        $base_path = ABSPATH;
        
        $files_to_sync = array();
        
        if (in_array('images', $file_types)) {
            $files_to_sync = array_merge($files_to_sync, $this->find_files_by_type($upload_dir['basedir'], array('jpg', 'jpeg', 'png', 'gif', 'webp')));
        }
        
        if (in_array('js', $file_types)) {
            $files_to_sync = array_merge($files_to_sync, $this->find_files_by_type($base_path, array('js')));
        }
        
        if (in_array('css', $file_types)) {
            $files_to_sync = array_merge($files_to_sync, $this->find_files_by_type($base_path, array('css')));
        }
        
        if (in_array('fonts', $file_types)) {
            $files_to_sync = array_merge($files_to_sync, $this->find_files_by_type($base_path, array('woff', 'woff2', 'ttf', 'eot', 'otf')));
        }
        
        $results = array();
        foreach ($files_to_sync as $file) {
            $github_path = str_replace($base_path, '', $file);
            $result = $this->upload_to_github($file, $github_path);
            $results[] = array(
                'file' => $github_path,
                'success' => $result
            );
        }
        
        return $results;
    }
    
    public function sync_full_wpcontent() {
        $wp_content_dir = WP_CONTENT_DIR;
        $files = $this->find_all_files($wp_content_dir);
        
        $results = array();
        foreach ($files as $file) {
            $github_path = str_replace($wp_content_dir, 'wp-content', $file);
            $result = $this->upload_to_github($file, $github_path);
            $results[] = array(
                'file' => $github_path,
                'success' => $result
            );
        }
        
        return $results;
    }
    
    private function upload_to_github($local_path, $github_path) {
        if (!file_exists($local_path)) return false;
        
        $api_url = 'https://api.github.com/repos/' . 
                  $this->settings->get_option('github_username') . '/' . 
                  $this->settings->get_option('github_repo') . '/contents/' . $github_path;
        
        $content = base64_encode(file_get_contents($local_path));
        $message = 'Auto-upload from WordPress: ' . basename($local_path);
        
        $data = array(
            'message' => $message,
            'content' => $content,
            'branch' => 'main'
        );
        
        $args = array(
            'headers' => array(
                'Authorization' => 'token ' . $this->settings->get_option('github_token'),
                'Accept' => 'application/vnd.github.v3+json'
            ),
            'body' => json_encode($data)
        );
        
        $response = wp_remote_put($api_url, $args);
        
        if (is_wp_error($response)) {
            error_log('GitHub upload error: ' . $response->get_error_message());
            return false;
        }
        
        return true;
    }
    
    private function find_files_by_type($directory, $extensions) {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        $files = array();
        
        foreach ($iterator as $file) {
            if ($file->isFile() && in_array(strtolower($file->getExtension()), $extensions)) {
                $files[] = $file->getPathname();
            }
        }
        
        return $files;
    }
    
    private function find_all_files($directory) {
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );
        
        $files = array();
        
        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $files[] = $file->getPathname();
            }
        }
        
        return $files;
    }
    
    private function sync_directory_to_github($local_dir, $github_dir) {
        $files = $this->find_all_files($local_dir);
        
        foreach ($files as $file) {
            $relative_path = str_replace($local_dir, '', $file);
            $github_path = $github_dir . $relative_path;
            $this->upload_to_github($file, $github_path);
        }
    }
}