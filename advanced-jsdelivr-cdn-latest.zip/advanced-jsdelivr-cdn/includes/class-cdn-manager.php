<?php
class Advanced_JSDelivr_CDN_Manager {
    private $settings;
    private $github_sync;
    private $mappings;
    private $admin_ui;
    
    public function __construct($settings, $github_sync, $mappings, $admin_ui) {
        $this->settings = $settings;
        $this->github_sync = $github_sync;
        $this->mappings = $mappings;
        $this->admin_ui = $admin_ui;
        $this->setup_hooks();
    }
    
    public function run() {
        // This method can be kept for backward compatibility
        // though setup_hooks() is now called in constructor
    }
    
    private function setup_hooks() {
        // CDN replacement hooks
        add_filter('style_loader_src', array($this, 'handle_cdn_replacement'), 999999, 2);
        add_filter('script_loader_src', array($this, 'handle_cdn_replacement'), 999999, 2);
        add_filter('wp_get_attachment_url', array($this, 'handle_attachment_url'), 999999);
        add_filter('the_content', array($this, 'handle_content_urls'), 999999);
        add_filter('custom_logo_url', array($this, 'handle_logo_url'), 999999);
        
        // GitHub auto-sync hooks
        if ($this->settings->get_option('github_auto_upload') === 'yes') {
            add_action('add_attachment', array($this->github_sync, 'handle_attachment_upload'));
            add_action('upgrader_process_complete', array($this->github_sync, 'handle_theme_plugin_update'), 10, 2);
        }
    }
    
    public function handle_cdn_replacement($src, $handle) {
        if (empty($src)) return $src;
        
        if ($this->settings->get_option('cdn_mode') === 'full') {
            return $this->force_full_cdn($src);
        }
        
        return $this->mappings->apply_selective_cdn($src);
    }
    
    public function handle_attachment_url($url) {
        if (empty($url)) return $url;
        
        if ($this->settings->get_option('cdn_mode') === 'full') {
            return $this->force_full_cdn($url);
        }
        
        return $this->mappings->apply_selective_cdn($url);
    }
    
    public function handle_content_urls($content) {
        if (empty($content)) return $content;
        
        if ($this->settings->get_option('cdn_mode') === 'full') {
            return $this->apply_full_cdn_to_content($content);
        }
        
        return $this->mappings->apply_selective_cdn_to_content($content);
    }
    
    public function handle_logo_url($url) {
        if (empty($url)) return $url;
        
        if ($this->settings->get_option('cdn_mode') === 'full') {
            return $this->force_full_cdn($url);
        }
        
        return $this->mappings->apply_selective_cdn($url);
    }
    
    private function force_full_cdn($url) {
        $site_url = site_url();
        $cdn_base = 'https://cdn.jsdelivr.net/gh/' . 
                   $this->settings->get_option('github_username') . '/' . 
                   $this->settings->get_option('github_repo') . '@latest';
        
        if (strpos($url, $site_url) !== false) {
            return str_replace($site_url, $cdn_base, $url);
        }
        
        if (strpos($url, content_url()) !== false) {
            $relative_path = str_replace(WP_CONTENT_DIR, '', $url);
            return $cdn_base . $relative_path;
        }
        
        return $url;
    }
    
    private function apply_full_cdn_to_content($content) {
        $site_url = site_url();
        $cdn_base = 'https://cdn.jsdelivr.net/gh/' . 
                   $this->settings->get_option('github_username') . '/' . 
                   $this->settings->get_option('github_repo') . '@latest';
        
        return str_replace($site_url, $cdn_base, $content);
    }
}