<?php
class Advanced_JSDelivr_Utilities {
    public static function normalize_url($url) {
        if (!is_string($url)) return '';
        $url = preg_replace('/^https?:/i', '', $url);
        $url = strtok($url, '?');
        return untrailingslashit($url);
    }
    
    public static function ensure_proper_url($url) {
        if (!is_string($url)) return '';
        $url = preg_replace('/^(https?:)+/i', 'https:', $url);
        return $url;
    }
    
    public static function get_query_string($url) {
        $query = parse_url($url, PHP_URL_QUERY);
        return $query ? '?' . $query : '';
    }
    
    public static function format_bytes($bytes, $precision = 2) {
        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        
        $bytes /= pow(1024, $pow);
        
        return round($bytes, $precision) . ' ' . $units[$pow];
    }
}