<?php
class Advanced_JSDelivr_Settings {
    private $options;
    
    public function __construct() {
        $this->options = get_option('advanced_jsdelivr_options', array(
            'cdn_mode' => 'selective',
            'github_auto_upload' => 'no',
            'github_username' => '',
            'github_repo' => '',
            'github_token' => '',
            'sync_file_types' => array('js', 'css'),
            'sync_schedule' => 'manual'
        ));
    }
    
    public function get_option($key, $default = '') {
        return isset($this->options[$key]) ? $this->options[$key] : $default;
    }
    
    public function get_all_options() {
        return $this->options;
    }
    
    public function register_settings() {
        register_setting('advanced_jsdelivr_group', 'advanced_jsdelivr_options', array(
            'sanitize_callback' => array($this, 'sanitize_options')
        ));
        
        // Main settings section
        add_settings_section(
            'advanced_jsdelivr_main',
            'Main Settings',
            array($this, 'render_main_section'),
            'advanced-jsdelivr-cdn'
        );
        
        // GitHub settings section
        add_settings_section(
            'advanced_jsdelivr_github',
            'GitHub Integration',
            array($this, 'render_github_section'),
            'advanced-jsdelivr-cdn'
        );
        
        // Sync settings section
        add_settings_section(
            'advanced_jsdelivr_sync',
            'Sync Settings',
            array($this, 'render_sync_section'),
            'advanced-jsdelivr-cdn'
        );
    }
    
    public function sanitize_options($input) {
        $output = array();
        
        // CDN mode validation
        $output['cdn_mode'] = isset($input['cdn_mode']) && in_array($input['cdn_mode'], array('full', 'selective')) 
            ? $input['cdn_mode'] 
            : 'selective';
            
        // GitHub auto-upload validation
        $output['github_auto_upload'] = isset($input['github_auto_upload']) && $input['github_auto_upload'] === 'yes' 
            ? 'yes' 
            : 'no';
            
        // GitHub credentials sanitization
        $output['github_username'] = sanitize_text_field($input['github_username']);
        $output['github_repo'] = sanitize_text_field($input['github_repo']);
        $output['github_token'] = sanitize_text_field($input['github_token']);
        
        // Sync file types validation
        $valid_file_types = array('js', 'css', 'images', 'fonts');
        $output['sync_file_types'] = array();
        
        if (isset($input['sync_file_types']) && is_array($input['sync_file_types'])) {
            foreach ($input['sync_file_types'] as $type) {
                if (in_array($type, $valid_file_types)) {
                    $output['sync_file_types'][] = $type;
                }
            }
        }
        
        // Sync schedule validation
        $output['sync_schedule'] = isset($input['sync_schedule']) && in_array($input['sync_schedule'], array('manual', 'daily', 'weekly')) 
            ? $input['sync_schedule'] 
            : 'manual';
        
        return $output;
    }
    
    public function render_main_section() {
        $data = array(
            'cdn_mode' => $this->get_option('cdn_mode'),
            'github_auto_upload' => $this->get_option('github_auto_upload')
        );
        extract($data);
        include ADVANCED_JSDELIVR_PLUGIN_DIR . 'templates/settings-main-section.php';
    }
    
    public function render_github_section() {
        $data = array(
            'github_username' => $this->get_option('github_username'),
            'github_repo' => $this->get_option('github_repo'),
            'github_token' => $this->get_option('github_token')
        );
        extract($data);
        include ADVANCED_JSDELIVR_PLUGIN_DIR . 'templates/settings-github-section.php';
    }
    
    public function render_sync_section() {
        $data = array(
            'sync_file_types' => $this->get_option('sync_file_types', array()),
            'sync_schedule' => $this->get_option('sync_schedule', 'manual')
        );
        extract($data);
        include ADVANCED_JSDELIVR_PLUGIN_DIR . 'templates/settings-sync-section.php';
    }
}