<?php
class Advanced_JSDelivr_Mappings {
    private $mappings;
    
    public function __construct() {
        $this->mappings = get_option('advanced_jsdelivr_mappings', array());
    }
    
    public function get_mappings() {
        return $this->mappings;
    }
    
    public function add_mapping($local_url, $cdn_url) {
        $new_key = md5($this->normalize_url($local_url));
        $this->mappings[$new_key] = array(
            'local' => $this->normalize_url($local_url),
            'cdn' => esc_url_raw($cdn_url)
        );
        return update_option('advanced_jsdelivr_mappings', $this->mappings);
    }
    
    public function delete_mapping($key) {
        if (isset($this->mappings[$key])) {
            unset($this->mappings[$key]);
            return update_option('advanced_jsdelivr_mappings', $this->mappings);
        }
        return false;
    }
    
    public function update_mappings($new_mappings) {
        $sanitized = array();
        
        foreach ($new_mappings as $key => $entry) {
            if (!empty($entry['local']) && !empty($entry['cdn'])) {
                $sanitized[sanitize_key($key)] = array(
                    'local' => $this->normalize_url($entry['local']),
                    'cdn' => esc_url_raw($entry['cdn'])
                );
            }
        }
        
        $this->mappings = $sanitized;
        return update_option('advanced_jsdelivr_mappings', $this->mappings);
    }
    
    public function apply_selective_cdn($url) {
        if (empty($url)) return $url;
        
        $normalized_url = $this->normalize_url($url);
        
        foreach ($this->mappings as $mapping) {
            if (!empty($mapping['local']) && $normalized_url === $this->normalize_url($mapping['local'])) {
                return $this->ensure_proper_url($mapping['cdn']) . $this->get_query_string($url);
            }
        }
        return $url;
    }
    
    public function apply_selective_cdn_to_content($content) {
        if (empty($this->mappings)) return $content;
        
        foreach ($this->mappings as $mapping) {
            if (empty($mapping['local']) || empty($mapping['cdn'])) continue;
            
            $local_url = $this->normalize_url($mapping['local']);
            $cdn_url = $this->ensure_proper_url($mapping['cdn']);
            
            $patterns = array(
                'http:' . preg_quote($local_url, '/'),
                'https:' . preg_quote($local_url, '/'),
                preg_quote(preg_replace('/^https?:/i', '', $local_url), '/')
            );
            
            $pattern = '/(' . implode('|', $patterns) . ')/i';
            
            $content = preg_replace_callback($pattern, function($matches) use ($cdn_url) {
                return strpos($matches[0], 'http') === 0 ? $cdn_url : preg_replace('/^https?:/i', '', $cdn_url);
            }, $content);
        }
        
        return $content;
    }
    
    private function normalize_url($url) {
        if (!is_string($url)) return '';
        $url = preg_replace('/^https?:/i', '', $url);
        $url = strtok($url, '?');
        return untrailingslashit($url);
    }
    
    private function ensure_proper_url($url) {
        if (!is_string($url)) return '';
        $url = preg_replace('/^(https?:)+/i', 'https:', $url);
        return $url;
    }
    
    private function get_query_string($url) {
        $query = parse_url($url, PHP_URL_QUERY);
        return $query ? '?' . $query : '';
    }
}