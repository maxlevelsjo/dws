<?php
/*
Plugin Name: Advanced jsDelivr CDN Manager
Description: Complete CDN solution with GitHub integration and full website CDN options
Version: 2.1.0
Author: Your Name
*/

defined('ABSPATH') || exit;

// Define plugin constants
define('ADVANCED_JSDELIVR_VERSION', '2.1.0');
define('ADVANCED_JSDELIVR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ADVANCED_JSDELIVR_PLUGIN_URL', plugin_dir_url(__FILE__));

// Manually load required files (more reliable than autoloader for WordPress plugins)
$required_files = [
    'includes/class-utilities.php',
    'includes/class-settings.php',
    'includes/class-github-sync.php',
    'includes/class-mappings.php',
    'includes/class-admin-ui.php',
    'includes/class-cdn-manager.php'
];

foreach ($required_files as $file) {
    $file_path = ADVANCED_JSDELIVR_PLUGIN_DIR . $file;
    if (file_exists($file_path)) {
        require_once $file_path;
    } else {
        wp_die(sprintf(
            __('Required plugin file missing: %s. Please reinstall the plugin.', 'advanced-jsdelivr-cdn'),
            $file
        ));
    }
}

// Initialize the plugin
function advanced_jsdelivr_init() {
    // Verify all required classes exist
    if (!class_exists('Advanced_JSDelivr_Settings') || 
        !class_exists('Advanced_JSDelivr_Github_Sync') ||
        !class_exists('Advanced_JSDelivr_Mappings') ||
        !class_exists('Advanced_JSDelivr_Admin_UI') ||
        !class_exists('Advanced_JSDelivr_CDN_Manager')) {
        wp_die(__('Plugin classes failed to load. Please reinstall the plugin.', 'advanced-jsdelivr-cdn'));
    }

    // Initialize components with proper dependency injection
    $settings = new Advanced_JSDelivr_Settings();
    $github_sync = new Advanced_JSDelivr_Github_Sync($settings);
    $mappings = new Advanced_JSDelivr_Mappings();
    $admin_ui = new Advanced_JSDelivr_Admin_UI($settings, $github_sync, $mappings);
    
    // Finally initialize the main plugin class
    $plugin = new Advanced_JSDelivr_CDN_Manager($settings, $github_sync, $mappings, $admin_ui);
    $plugin->run();
}

// Hook initialization later to ensure all WordPress functions are available
add_action('plugins_loaded', 'advanced_jsdelivr_init', 10);

// Activation/Deactivation hooks
register_activation_hook(__FILE__, function() {
    // Set default options on activation
    $default_options = [
        'cdn_mode' => 'selective',
        'github_auto_upload' => 'no',
        'github_username' => '',
        'github_repo' => '',
        'github_token' => '',
        'sync_file_types' => ['js', 'css'],
        'sync_schedule' => 'manual'
    ];
    
    if (!get_option('advanced_jsdelivr_options')) {
        update_option('advanced_jsdelivr_options', $default_options);
    }
    
    if (!get_option('advanced_jsdelivr_mappings')) {
        update_option('advanced_jsdelivr_mappings', []);
    }
});

register_deactivation_hook(__FILE__, function() {
    // Clean up scheduled events on deactivation
    wp_clear_scheduled_hook('advanced_jsdelivr_scheduled_sync');
});