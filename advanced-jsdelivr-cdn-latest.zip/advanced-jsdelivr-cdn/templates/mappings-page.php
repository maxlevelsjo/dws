<div class="wrap">
    <h1><?php esc_html_e('CDN URL Mappings', 'advanced-jsdelivr-cdn'); ?></h1>
    
    <?php settings_errors('advanced_jsdelivr_messages'); ?>
    
    <div class="card">
        <h2><?php esc_html_e('Current CDN Mappings', 'advanced-jsdelivr-cdn'); ?></h2>
        <form method="post" action="options.php">
            <?php settings_fields('advanced_jsdelivr_group'); ?>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Local URL', 'advanced-jsdelivr-cdn'); ?></th>
                        <th><?php esc_html_e('CDN URL', 'advanced-jsdelivr-cdn'); ?></th>
                        <th><?php esc_html_e('Actions', 'advanced-jsdelivr-cdn'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $mappings = $this->mappings->get_mappings(); ?>
                    <?php if (empty($mappings)): ?>
                        <tr>
                            <td colspan="3"><?php esc_html_e('No CDN mappings yet', 'advanced-jsdelivr-cdn'); ?></td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($mappings as $key => $mapping): ?>
                            <tr>
                                <td><input type="text" name="advanced_jsdelivr_mappings[<?php echo esc_attr($key); ?>][local]" value="<?php echo esc_attr($mapping['local']); ?>" class="large-text"></td>
                                <td><input type="text" name="advanced_jsdelivr_mappings[<?php echo esc_attr($key); ?>][cdn]" value="<?php echo esc_attr($mapping['cdn']); ?>" class="large-text"></td>
                                <td>
                                    <button type="submit" name="advanced_jsdelivr_action" value="delete" class="button button-secondary"><?php esc_html_e('Delete', 'advanced-jsdelivr-cdn'); ?></button>
                                    <input type="hidden" name="delete_key" value="<?php echo esc_attr($key); ?>">
                                    <?php wp_nonce_field('advanced_jsdelivr_actions'); ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php submit_button(__('Save Mappings', 'advanced-jsdelivr-cdn'), 'primary', 'submit', false); ?>
        </form>
        
        <h2><?php esc_html_e('Add New Mapping', 'advanced-jsdelivr-cdn'); ?></h2>
        <form method="post">
            <?php wp_nonce_field('advanced_jsdelivr_actions'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="new_local_url"><?php esc_html_e('Local URL', 'advanced-jsdelivr-cdn'); ?></label></th>
                    <td>
                        <input type="text" name="new_local_url" id="new_local_url" class="large-text" placeholder="https://yoursite.com/wp-content/..." required>
                        <p class="description"><?php esc_html_e('Example: /wp-content/themes/your-theme/assets/fonts/icon-font.woff2', 'advanced-jsdelivr-cdn'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th><label for="new_cdn_url"><?php esc_html_e('jsDelivr URL', 'advanced-jsdelivr-cdn'); ?></label></th>
                    <td>
                        <input type="text" name="new_cdn_url" id="new_cdn_url" class="large-text" placeholder="https://cdn.jsdelivr.net/gh/username/repo@latest/file.ext" required>
                        <p class="description"><?php esc_html_e('Example: https://cdn.jsdelivr.net/gh/maxlevelsjo/dws@latest/fonts/icon-font.woff2', 'advanced-jsdelivr-cdn'); ?></p>
                    </td>
                </tr>
            </table>
            <input type="hidden" name="advanced_jsdelivr_action" value="add">
            <?php submit_button(__('Add Mapping', 'advanced-jsdelivr-cdn'), 'primary', 'submit', false); ?>
        </form>
    </div>
</div>