<table class="form-table">
    <tr>
        <th><label for="cdn_mode"><?php esc_html_e('CDN Mode', 'advanced-jsdelivr-cdn'); ?></label></th>
        <td>
            <select name="advanced_jsdelivr_options[cdn_mode]" id="cdn_mode" class="regular-text">
                <option value="selective" <?php selected($this->get_option('cdn_mode'), 'selective'); ?>>
                    <?php esc_html_e('Selective - Only replace specified URLs', 'advanced-jsdelivr-cdn'); ?>
                </option>
                <option value="full" <?php selected($this->get_option('cdn_mode'), 'full'); ?>>
                    <?php esc_html_e('Full Website - Replace all local URLs with CDN', 'advanced-jsdelivr-cdn'); ?>
                </option>
            </select>
            <p class="description">
                <?php esc_html_e('Selective mode requires manual URL mappings. Full mode automatically uses your GitHub repository.', 'advanced-jsdelivr-cdn'); ?>
            </p>
        </td>
    </tr>
    <tr>
        <th><label for="github_auto_upload"><?php esc_html_e('Auto-upload to GitHub', 'advanced-jsdelivr-cdn'); ?></label></th>
        <td>
            <select name="advanced_jsdelivr_options[github_auto_upload]" id="github_auto_upload" class="regular-text">
                <option value="no" <?php selected($this->get_option('github_auto_upload'), 'no'); ?>>
                    <?php esc_html_e('No', 'advanced-jsdelivr-cdn'); ?>
                </option>
                <option value="yes" <?php selected($this->get_option('github_auto_upload'), 'yes'); ?>>
                    <?php esc_html_e('Yes', 'advanced-jsdelivr-cdn'); ?>
                </option>
            </select>
            <p class="description">
                <?php esc_html_e('Automatically upload new media and theme/plugin updates to GitHub', 'advanced-jsdelivr-cdn'); ?>
            </p>
        </td>
    </tr>
</table>