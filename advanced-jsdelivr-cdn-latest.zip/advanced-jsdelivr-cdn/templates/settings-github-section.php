<div id="github-settings">
    <table class="form-table">
        <tr>
            <th><label for="github_username"><?php esc_html_e('GitHub Username', 'advanced-jsdelivr-cdn'); ?></label></th>
            <td>
                <input type="text" name="advanced_jsdelivr_options[github_username]" id="github_username" 
                       value="<?php echo esc_attr($this->get_option('github_username')); ?>" class="regular-text">
                <p class="description">
                    <?php esc_html_e('Your GitHub username or organization name', 'advanced-jsdelivr-cdn'); ?>
                </p>
            </td>
        </tr>
        <tr>
            <th><label for="github_repo"><?php esc_html_e('GitHub Repository', 'advanced-jsdelivr-cdn'); ?></label></th>
            <td>
                <input type="text" name="advanced_jsdelivr_options[github_repo]" id="github_repo" 
                       value="<?php echo esc_attr($this->get_option('github_repo')); ?>" class="regular-text">
                <p class="description">
                    <?php esc_html_e('The repository name where files will be stored', 'advanced-jsdelivr-cdn'); ?>
                </p>
            </td>
        </tr>
        <tr>
            <th><label for="github_token"><?php esc_html_e('GitHub Token', 'advanced-jsdelivr-cdn'); ?></label></th>
            <td>
                <input type="password" name="advanced_jsdelivr_options[github_token]" id="github_token" 
                       value="<?php echo esc_attr($this->get_option('github_token')); ?>" class="regular-text">
                <p class="description">
                    <?php esc_html_e('Create a personal access token with repo permissions', 'advanced-jsdelivr-cdn'); ?>
                </p>
            </td>
        </tr>
    </table>
    
    <div class="notice notice-info">
        <p><strong><?php esc_html_e('Important Notes:', 'advanced-jsdelivr-cdn'); ?></strong></p>
        <ol>
            <li><?php esc_html_e('Your repository structure should match your WordPress installation', 'advanced-jsdelivr-cdn'); ?></li>
            <li><?php esc_html_e('For full website CDN mode, upload your entire wp-content directory to GitHub', 'advanced-jsdelivr-cdn'); ?></li>
            <li><?php esc_html_e('The token needs "repo" scope permissions', 'advanced-jsdelivr-cdn'); ?></li>
            <li><?php esc_html_e('Test with a staging site first to avoid breaking your production site', 'advanced-jsdelivr-cdn'); ?></li>
        </ol>
    </div>
</div>