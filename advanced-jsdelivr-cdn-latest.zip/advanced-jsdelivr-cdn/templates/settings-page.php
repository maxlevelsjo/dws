<div class="wrap">
    <h1><?php esc_html_e('jsDelivr CDN Settings', 'advanced-jsdelivr-cdn'); ?></h1>
    
    <?php settings_errors('advanced_jsdelivr_messages'); ?>
    
    <form method="post" action="options.php" class="jsdelivr-settings-form">
        <?php 
        settings_fields('advanced_jsdelivr_group'); 
        do_settings_sections('advanced-jsdelivr-cdn');
        submit_button(__('Save Settings', 'advanced-jsdelivr-cdn'), 'primary', 'submit', false);
        ?>
    </form>
    
    <?php if ($github_auto_upload === 'yes') : ?>
    <div class="notice notice-warning">
        <p><strong><?php esc_html_e('Important:', 'advanced-jsdelivr-cdn'); ?></strong> 
           <?php esc_html_e('GitHub auto-upload is enabled. All new uploads will be automatically pushed to your GitHub repository.', 'advanced-jsdelivr-cdn'); ?>
        </p>
        <p><?php esc_html_e('Make sure your GitHub token has proper permissions and your repository structure matches your WordPress installation.', 'advanced-jsdelivr-cdn'); ?></p>
    </div>
    <?php endif; ?>
    
    <div class="card connection-status">
        <h3><?php esc_html_e('Connection Status', 'advanced-jsdelivr-cdn'); ?></h3>
        <div id="github-connection-test">
            <button id="test-github-connection" class="button button-secondary">
                <?php esc_html_e('Test GitHub Connection Now', 'advanced-jsdelivr-cdn'); ?>
            </button>
            <span id="connection-status-icon" class="dashicons dashicons-info"></span>
            <span id="connection-status-message"></span>
        </div>
    </div>
</div>

<style>
    .jsdelivr-settings-form {
        background: #fff;
        padding: 20px;
        margin-bottom: 20px;
        border: 1px solid #ccd0d4;
        box-shadow: 0 1px 1px rgba(0,0,0,0.04);
    }
    .connection-status {
        margin-top: 20px;
        padding: 15px;
    }
    #connection-status-icon {
        margin-left: 10px;
        vertical-align: middle;
    }
    #connection-status-message {
        margin-left: 5px;
    }
    .dashicons-yes {
        color: #46b450;
    }
    .dashicons-no {
        color: #dc3232;
    }
</style>

<script>
jQuery(document).ready(function($) {
    $('#test-github-connection').on('click', function() {
        var $button = $(this);
        var $icon = $('#connection-status-icon');
        var $message = $('#connection-status-message');
        
        $button.prop('disabled', true);
        $icon.removeClass().addClass('dashicons dashicons-update-alt');
        $message.text('Testing connection...');
        
        // Get fresh nonce via AJAX
        $.post(ajaxurl, {
            action: 'get_connection_test_nonce'
        }, function(nonceResponse) {
            if (!nonceResponse.success) {
                $icon.removeClass().addClass('dashicons dashicons-no');
                $message.text('Failed to get security token');
                $button.prop('disabled', false);
                return;
            }

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'test_github_connection',
                    _ajax_nonce: nonceResponse.nonce
                },
                timeout: 20000,
                success: function(response) {
                    if (response.success) {
                        $icon.removeClass().addClass('dashicons dashicons-yes');
                        $message.text(response.data);
                    } else {
                        $icon.removeClass().addClass('dashicons dashicons-no');
                        $message.text('Error: ' + response.data);
                    }
                },
                error: function(xhr) {
                    $icon.removeClass().addClass('dashicons dashicons-no');
                    if (xhr.responseJSON && xhr.responseJSON.data) {
                        $message.text(xhr.responseJSON.data);
                    } else {
                        $message.text('Connection failed. Check console for details.');
                    }
                    console.error('Connection Error:', xhr.responseText);
                },
                complete: function() {
                    $button.prop('disabled', false);
                }
            });
        });
    });
});
</script>