<div class="wrap">
    <h1><?php esc_html_e('GitHub Sync', 'advanced-jsdelivr-cdn'); ?></h1>
    
    <?php settings_errors('advanced_jsdelivr_messages'); ?>
    
    <div class="card">
        <h2><?php esc_html_e('GitHub Connection Test', 'advanced-jsdelivr-cdn'); ?></h2>
        <div id="github-connection-test">
            <button id="test-github-connection" class="button button-primary">
                <?php esc_html_e('Test GitHub Connection', 'advanced-jsdelivr-cdn'); ?>
            </button>
            <div id="connection-result" class="result-message" style="margin-top: 10px;"></div>
        </div>
    </div>
    
    <div class="card">
        <h2><?php esc_html_e('Sync Selected File Types', 'advanced-jsdelivr-cdn'); ?></h2>
        <p><?php esc_html_e('Select the file types you want to sync to GitHub:', 'advanced-jsdelivr-cdn'); ?></p>
        
        <form id="sync-selected-form">
            <fieldset>
                <label>
                    <input type="checkbox" name="file_types[]" value="js" <?php checked(in_array('js', $sync_file_types)); ?>>
                    <?php esc_html_e('JavaScript (.js)', 'advanced-jsdelivr-cdn'); ?>
                </label><br>
                <label>
                    <input type="checkbox" name="file_types[]" value="css" <?php checked(in_array('css', $sync_file_types)); ?>>
                    <?php esc_html_e('CSS (.css)', 'advanced-jsdelivr-cdn'); ?>
                </label><br>
                <label>
                    <input type="checkbox" name="file_types[]" value="images" <?php checked(in_array('images', $sync_file_types)); ?>>
                    <?php esc_html_e('Images (.jpg, .png, .gif, etc.)', 'advanced-jsdelivr-cdn'); ?>
                </label><br>
                <label>
                    <input type="checkbox" name="file_types[]" value="fonts" <?php checked(in_array('fonts', $sync_file_types)); ?>>
                    <?php esc_html_e('Fonts (.woff, .woff2, .ttf, etc.)', 'advanced-jsdelivr-cdn'); ?>
                </label>
            </fieldset>
            
            <button type="submit" id="sync-selected-files" class="button button-primary" style="margin-top: 15px;">
                <?php esc_html_e('Sync Selected Files', 'advanced-jsdelivr-cdn'); ?>
            </button>
            
            <div id="sync-selected-result" class="result-message" style="margin-top: 10px;"></div>
        </form>
    </div>
    
    <div class="card">
        <h2><?php esc_html_e('Full wp-content Sync', 'advanced-jsdelivr-cdn'); ?></h2>
        <p><?php esc_html_e('This will sync your entire wp-content directory to GitHub. This may take a while.', 'advanced-jsdelivr-cdn'); ?></p>
        
        <button id="sync-full-wpcontent" class="button button-primary">
            <?php esc_html_e('Sync wp-content Directory', 'advanced-jsdelivr-cdn'); ?>
        </button>
        
        <div id="sync-full-result" class="result-message" style="margin-top: 10px;"></div>
    </div>
</div>