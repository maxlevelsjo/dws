<?php
// Get the current settings
$sync_file_types = $this->get_option('sync_file_types', []);
$sync_schedule = $this->get_option('sync_schedule', 'manual');
?>

<table class="form-table">
    <tr>
        <th><label><?php esc_html_e('Auto-sync File Types', 'advanced-jsdelivr-cdn'); ?></label></th>
        <td>
            <fieldset>
                <label>
                    <input type="checkbox" name="advanced_jsdelivr_options[sync_file_types][]" value="js" <?php checked(in_array('js', $sync_file_types)); ?>>
                    <?php esc_html_e('JavaScript (.js)', 'advanced-jsdelivr-cdn'); ?>
                </label><br>
                <label>
                    <input type="checkbox" name="advanced_jsdelivr_options[sync_file_types][]" value="css" <?php checked(in_array('css', $sync_file_types)); ?>>
                    <?php esc_html_e('CSS (.css)', 'advanced-jsdelivr-cdn'); ?>
                </label><br>
                <label>
                    <input type="checkbox" name="advanced_jsdelivr_options[sync_file_types][]" value="images" <?php checked(in_array('images', $sync_file_types)); ?>>
                    <?php esc_html_e('Images (.jpg, .png, .gif, etc.)', 'advanced-jsdelivr-cdn'); ?>
                </label><br>
                <label>
                    <input type="checkbox" name="advanced_jsdelivr_options[sync_file_types][]" value="fonts" <?php checked(in_array('fonts', $sync_file_types)); ?>>
                    <?php esc_html_e('Fonts (.woff, .woff2, .ttf, etc.)', 'advanced-jsdelivr-cdn'); ?>
                </label>
            </fieldset>
            <p class="description">
                <?php esc_html_e('Select which file types should be automatically synced to GitHub when modified', 'advanced-jsdelivr-cdn'); ?>
            </p>
        </td>
    </tr>
    <tr>
        <th><label for="sync_schedule"><?php esc_html_e('Sync Schedule', 'advanced-jsdelivr-cdn'); ?></label></th>
        <td>
            <select name="advanced_jsdelivr_options[sync_schedule]" id="sync_schedule" class="regular-text">
                <option value="manual" <?php selected($sync_schedule, 'manual'); ?>>
                    <?php esc_html_e('Manual Only', 'advanced-jsdelivr-cdn'); ?>
                </option>
                <option value="daily" <?php selected($sync_schedule, 'daily'); ?>>
                    <?php esc_html_e('Daily', 'advanced-jsdelivr-cdn'); ?>
                </option>
                <option value="weekly" <?php selected($sync_schedule, 'weekly'); ?>>
                    <?php esc_html_e('Weekly', 'advanced-jsdelivr-cdn'); ?>
                </option>
            </select>
            <p class="description">
                <?php esc_html_e('How often should the plugin check for file changes to sync', 'advanced-jsdelivr-cdn'); ?>
            </p>
        </td>
    </tr>
</table>