jQuery(document).ready(function($) {
    // Auto-fill CDN URL based on GitHub settings
    $('#new_local_url').on('blur', function() {
        var localUrl = $(this).val();
        if (localUrl && !$('#new_cdn_url').val()) {
            var githubUser = $('#github_username').val();
            var githubRepo = $('#github_repo').val();
            
            if (githubUser && githubRepo) {
                var filename = localUrl.split('/').pop();
                if (filename) {
                    $('#new_cdn_url').val('https://cdn.jsdelivr.net/gh/' + githubUser + '/' + githubRepo + '@latest/' + filename);
                }
            }
        }
    });
    
    // Test GitHub connection
    $('#test-github-connection').on('click', function(e) {
        e.preventDefault();
        var $button = $(this);
        var $result = $('#connection-result');
        
        $button.prop('disabled', true).text(advanced_jsdelivr.testing_connection);
        $result.removeClass('error success').text('');
        
        $.ajax({
            url: advanced_jsdelivr.ajax_url,
            type: 'POST',
            data: {
                action: 'test_github_connection',
                nonce: advanced_jsdelivr.nonce
            },
            success: function(response) {
                if (response.success) {
                    $result.addClass('success').text(response.data);
                } else {
                    $result.addClass('error').text(response.data);
                }
            },
            error: function(xhr, status, error) {
                $result.addClass('error').text('AJAX error: ' + error);
            },
            complete: function() {
                $button.prop('disabled', false).text('Test GitHub Connection');
            }
        });
    });
    
    // Sync selected files
    $('#sync-selected-form').on('submit', function(e) {
        e.preventDefault();
        var $button = $('#sync-selected-files');
        var $result = $('#sync-selected-result');
        var fileTypes = $(this).find('input[name="file_types[]"]:checked').map(function() {
            return this.value;
        }).get();
        
        if (fileTypes.length === 0) {
            $result.addClass('error').text('Please select at least one file type.');
            return;
        }
        
        $button.prop('disabled', true).text(advanced_jsdelivr.syncing_files);
        $result.removeClass('error success').text('');
        
        $.ajax({
            url: advanced_jsdelivr.ajax_url,
            type: 'POST',
            data: {
                action: 'sync_selected_files',
                file_types: fileTypes,
                nonce: advanced_jsdelivr.nonce
            },
            success: function(response) {
                if (response.success) {
                    var message = response.data.message;
                    var results = response.data.results;
                    var failed = results.filter(function(item) { return !item.success; }).length;
                    
                    if (failed > 0) {
                        message += ' ' + failed + ' files failed to sync.';
                    }
                    
                    $result.addClass('success').text(message);
                } else {
                    $result.addClass('error').text(response.data);
                }
            },
            error: function(xhr, status, error) {
                $result.addClass('error').text('AJAX error: ' + error);
            },
            complete: function() {
                $button.prop('disabled', false).text('Sync Selected Files');
            }
        });
    });
    
    // Sync full wp-content
    $('#sync-full-wpcontent').on('click', function(e) {
        e.preventDefault();
        var $button = $(this);
        var $result = $('#sync-full-result');
        
        if (!confirm('Are you sure you want to sync your entire wp-content directory? This may take a while.')) {
            return;
        }
        
        $button.prop('disabled', true).text(advanced_jsdelivr.syncing_files);
        $result.removeClass('error success').text('');
        
        $.ajax({
            url: advanced_jsdelivr.ajax_url,
            type: 'POST',
            data: {
                action: 'sync_full_wpcontent',
                nonce: advanced_jsdelivr.nonce
            },
            success: function(response) {
                if (response.success) {
                    var message = response.data.message;
                    var results = response.data.results;
                    var failed = results.filter(function(item) { return !item.success; }).length;
                    
                    if (failed > 0) {
                        message += ' ' + failed + ' files failed to sync.';
                    }
                    
                    $result.addClass('success').text(message);
                } else {
                    $result.addClass('error').text(response.data);
                }
            },
            error: function(xhr, status, error) {
                $result.addClass('error').text('AJAX error: ' + error);
            },
            complete: function() {
                $button.prop('disabled', false).text('Sync wp-content Directory');
            }
        });
    });
});